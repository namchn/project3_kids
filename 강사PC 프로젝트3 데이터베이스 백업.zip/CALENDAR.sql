--------------------------------------------------------
--  ������ ������ - ������-3��-11-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table CALENDAR
--------------------------------------------------------

  CREATE TABLE "PROJECT3"."CALENDAR" 
   (	"NUM" NUMBER(30,0), 
	"ID" VARCHAR2(50 BYTE), 
	"START_DATE" DATE DEFAULT sysdate, 
	"END_DATE" DATE DEFAULT sysdate, 
	"EVENT" VARCHAR2(100 BYTE) DEFAULT '����'
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into PROJECT3.CALENDAR
SET DEFINE OFF;
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (212,'manager',to_date('19/02/04','RR/MM/DD'),to_date('19/02/06','RR/MM/DD'),'������');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (213,'manager',to_date('19/03/01','RR/MM/DD'),to_date('19/03/01','RR/MM/DD'),'������');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (214,'manager',to_date('19/03/12','RR/MM/DD'),to_date('19/03/12','RR/MM/DD'),'�����ð��� <�ҵ��ϴ� ����!>');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (215,'manager',to_date('19/03/22','RR/MM/DD'),to_date('19/03/22','RR/MM/DD'),'�������̱� <��� ã�Ƽ�>');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (216,'manager',to_date('19/03/24','RR/MM/DD'),to_date('19/04/02','RR/MM/DD'),'1�б� �кθ���');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (217,'manager',to_date('19/04/05','RR/MM/DD'),to_date('19/04/05','RR/MM/DD'),'Special Day - �ĸ���');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (218,'manager',to_date('19/04/18','RR/MM/DD'),to_date('19/04/18','RR/MM/DD'),'����ǳ');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (219,'manager',to_date('19/04/29','RR/MM/DD'),to_date('19/04/30','RR/MM/DD'),'���� - ����â�ǳ��� <�����󳪶�>');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (220,'manager',to_date('19/05/01','RR/MM/DD'),to_date('19/05/01','RR/MM/DD'),'�ٷ����� ��');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (221,'manager',to_date('19/05/05','RR/MM/DD'),to_date('19/05/05','RR/MM/DD'),'��� ��');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (222,'manager',to_date('19/05/12','RR/MM/DD'),to_date('19/05/12','RR/MM/DD'),'����ź����');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (223,'manager',to_date('19/06/06','RR/MM/DD'),to_date('19/06/06','RR/MM/DD'),'������');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (224,'manager',to_date('19/08/15','RR/MM/DD'),to_date('19/08/15','RR/MM/DD'),'������');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (225,'manager',to_date('19/09/12','RR/MM/DD'),to_date('19/09/14','RR/MM/DD'),'�߼�����');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (226,'manager',to_date('19/10/03','RR/MM/DD'),to_date('19/10/03','RR/MM/DD'),'��õ��');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (227,'manager',to_date('19/10/09','RR/MM/DD'),to_date('19/10/09','RR/MM/DD'),'�ѱ۳�');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (228,'manager',to_date('19/12/25','RR/MM/DD'),to_date('19/12/25','RR/MM/DD'),'��ź��');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (229,'manager',to_date('19/03/07','RR/MM/DD'),to_date('19/03/07','RR/MM/DD'),'2018 ����İ��� ù ������');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (230,'manager',to_date('19/07/15','RR/MM/DD'),to_date('19/07/31','RR/MM/DD'),'��������');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (232,'manager',to_date('19/03/17','RR/MM/DD'),to_date('19/03/19','RR/MM/DD'),'�θ�԰� �Բ��ϴ� ������');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (210,'manager',to_date('19/03/04','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),'������ġ�� ���н�');
Insert into PROJECT3.CALENDAR (NUM,ID,START_DATE,END_DATE,EVENT) values (211,'manager',to_date('19/01/01','RR/MM/DD'),to_date('19/01/01','RR/MM/DD'),'����');
