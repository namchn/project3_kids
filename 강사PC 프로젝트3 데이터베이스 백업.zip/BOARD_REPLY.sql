--------------------------------------------------------
--  ������ ������ - ������-3��-11-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table BOARD_REPLY
--------------------------------------------------------

  CREATE TABLE "PROJECT3"."BOARD_REPLY" 
   (	"BOARD_CODE" VARCHAR2(30 BYTE), 
	"NUM" NUMBER(30,0), 
	"REPLY_NUM" NUMBER(30,0), 
	"ID" VARCHAR2(50 BYTE), 
	"TIME" DATE, 
	"CONTENT" VARCHAR2(3000 BYTE)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into PROJECT3.BOARD_REPLY
SET DEFINE OFF;
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',117,182,'t11',to_date('19/02/25','RR/MM/DD'),'???');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',141,201,'t11',to_date('19/02/25','RR/MM/DD'),'0439');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',141,203,'t11',to_date('19/02/25','RR/MM/DD'),'0439');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',141,202,'t11',to_date('19/02/25','RR/MM/DD'),'0439');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',121,204,'t11',to_date('19/02/25','RR/MM/DD'),'������!');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',121,205,'manager',to_date('19/02/25','RR/MM/DD'),'ll');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',115,206,'t11',to_date('19/02/25','RR/MM/DD'),'aaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',115,207,'t11',to_date('19/02/25','RR/MM/DD'),'bbb');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',115,208,'t11',to_date('19/02/25','RR/MM/DD'),'bbb');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',115,209,'t11',to_date('19/02/25','RR/MM/DD'),'ccc');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',115,210,'t11',to_date('19/02/25','RR/MM/DD'),'ddd');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',115,211,'t11',to_date('19/02/25','RR/MM/DD'),'eeeee');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',141,212,'t11',to_date('19/02/25','RR/MM/DD'),'aaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',122,216,'t11',to_date('19/02/27','RR/MM/DD'),'aaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',149,214,'t11',to_date('19/02/26','RR/MM/DD'),'ccv');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',125,215,'manager',to_date('19/02/26','RR/MM/DD'),'g');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',138,235,'t22',to_date('19/02/27','RR/MM/DD'),'aaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',155,237,'t22',to_date('19/02/27','RR/MM/DD'),'bbb');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',143,219,'t11',to_date('19/02/27','RR/MM/DD'),'sss');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',143,220,'t11',to_date('19/02/27','RR/MM/DD'),'DDD');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',143,221,'t11',to_date('19/02/27','RR/MM/DD'),'AAA');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',143,222,'t11',to_date('19/02/27','RR/MM/DD'),'AAA');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',143,223,'t11',to_date('19/02/27','RR/MM/DD'),'VVV');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',143,224,'t11',to_date('19/02/27','RR/MM/DD'),'AAA');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',143,225,'t11',to_date('19/02/27','RR/MM/DD'),'aaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',143,226,'t11',to_date('19/02/27','RR/MM/DD'),'��� �׽�Ʈ���Դϴ�. �׽�Ʈ���Դϴ�. �׽�Ʈ���Դϴ�.');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',138,234,'t22',to_date('19/02/27','RR/MM/DD'),'bbb');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',152,232,'t22',to_date('19/02/27','RR/MM/DD'),'aaaaaaaaaaaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',152,243,'t11',to_date('19/02/28','RR/MM/DD'),'������');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',153,247,'t22',to_date('19/02/28','RR/MM/DD'),'aaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',152,240,'t22',to_date('19/02/27','RR/MM/DD'),'aaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',156,242,'t11',to_date('19/02/28','RR/MM/DD'),'aaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',152,244,'t11',to_date('19/02/28','RR/MM/DD'),'������');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',152,245,'t22',to_date('19/03/01','RR/MM/DD'),'bbbbbbbbbbbbbbbaaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',166,274,'t',to_date('19/03/01','RR/MM/DD'),'��������');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',155,248,'t22',to_date('19/02/28','RR/MM/DD'),'aaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',155,249,'t22',to_date('19/02/28','RR/MM/DD'),'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',143,263,'t11',to_date('19/02/28','RR/MM/DD'),'��� ���� ����');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',161,265,'t11',to_date('19/02/28','RR/MM/DD'),'aaaaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',143,264,'t11',to_date('19/02/28','RR/MM/DD'),'��� ���� ������� ���� ������� ���� ������� ���� ������� ���� ������� ���� ������� ���� ������� ���� ������� ���� ������� ���� ����');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',161,266,'t11',to_date('19/02/28','RR/MM/DD'),'aaaaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',161,267,'t11',to_date('19/02/28','RR/MM/DD'),'vvv');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',162,268,'t11',to_date('19/02/28','RR/MM/DD'),'�츮���̾߱� ��̹��̳׿�');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',153,269,'t11',to_date('19/02/28','RR/MM/DD'),'������');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',153,272,'t11',to_date('19/02/28','RR/MM/DD'),'�����ٶ󸶹ٻ�');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',166,275,'t',to_date('19/03/01','RR/MM/DD'),'��������������');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',152,273,'t22',to_date('19/03/01','RR/MM/DD'),'ddd');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',161,276,'t',to_date('19/03/01','RR/MM/DD'),'��������������');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',177,277,'hyesooya',to_date('19/03/01','RR/MM/DD'),'�� �����ϰڽ��ϴ�.');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',156,278,'hyesooya',to_date('19/03/01','RR/MM/DD'),'��۵帳�ϴ�.');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',156,279,'hyesooya',to_date('19/03/01','RR/MM/DD'),'���Բ� �뷡 �սô�');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',161,280,'hyesooya',to_date('19/03/01','RR/MM/DD'),'�ǳ��� ��� ����?');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',179,281,'t',to_date('19/03/01','RR/MM/DD'),'antmsthflsadifkjkljklsjdkljfklsjdkljkltjksldjtlasdjlktjklasdjt jaslkdjflkasjdlfjlksadfkl');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',179,282,'t',to_date('19/03/01','RR/MM/DD'),'asdfasdfasdf ��������ӾƤӤä��Ӥ��Ӥ� ���ն�Ӥä����� askdjfk');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',179,283,'t',to_date('19/03/01','RR/MM/DD'),'antmsthlfskdfjisdf');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',179,284,'t',to_date('19/03/01','RR/MM/DD'),'�Ǵµ� �ǳ� �ȵǳ�');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',161,285,'t',to_date('19/03/01','RR/MM/DD'),'�ɱ�? �ɰž� �ȴٰ� ����');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',161,286,'hyesooya',to_date('19/03/01','RR/MM/DD'),'���');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',179,287,'hyesooya',to_date('19/03/01','RR/MM/DD'),'���� ����� ä�� ��Ź �帳�ϴ�.');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',162,300,'manager',to_date('19/03/02','RR/MM/DD'),'����Ͽ��� �߾��� ���ƿ�');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',163,297,'t22',to_date('19/03/01','RR/MM/DD'),'���� ��̹��̾߾� �¾� �� ��̹��̾�');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',164,302,'manager',to_date('19/03/02','RR/MM/DD'),'��̹ݿ� �߾��� ����^^');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',161,299,'t22',to_date('19/03/01','RR/MM/DD'),'�����Խ����̴� �����׽�Ʈ');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',161,292,'t22',to_date('19/03/01','RR/MM/DD'),'������ �Ŀ�� �Ժθ�');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',179,298,'t22',to_date('19/03/01','RR/MM/DD'),'alert ������');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',165,301,'manager',to_date('19/03/02','RR/MM/DD'),'������ ������ �԰ڽ��ϱ�?');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',163,295,'t22',to_date('19/03/01','RR/MM/DD'),'�������� �ϳ� �عٶ����̾߾� ��׷�');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',164,303,'manager',to_date('19/03/02','RR/MM/DD'),'asdf');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',179,321,'manager',to_date('19/03/03','RR/MM/DD'),'�ξƿ� �޴��̴� �׻� ���� ģ������~^^');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',177,322,'manager',to_date('19/03/03','RR/MM/DD'),'�ֵ��� �� �Ϳ��׿�');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',179,323,'chun4',to_date('19/03/04','RR/MM/DD'),'�� �ǳ׿�');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('bulletin',219,324,'chun4',to_date('19/03/04','RR/MM/DD'),'���� �ּ���');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('gallery',179,325,'chun6',to_date('19/03/04','RR/MM/DD'),'�ȳ��ϼ���');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',92,164,'manager',to_date('19/02/22','RR/MM/DD'),'aaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',92,165,'manager',to_date('19/02/22','RR/MM/DD'),'bbbbb');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',102,168,'manager',to_date('19/02/22','RR/MM/DD'),'aaa');
Insert into PROJECT3.BOARD_REPLY (BOARD_CODE,NUM,REPLY_NUM,ID,TIME,CONTENT) values ('notice',102,169,'manager',to_date('19/02/22','RR/MM/DD'),'bbb');
