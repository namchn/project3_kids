--------------------------------------------------------
--  ������ ������ - ������-3��-11-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table CART
--------------------------------------------------------

  CREATE TABLE "PROJECT3"."CART" 
   (	"CART_NUM" NUMBER(30,0), 
	"ID" VARCHAR2(50 BYTE), 
	"BOOK_NUM" NUMBER(30,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into PROJECT3.CART
SET DEFINE OFF;
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (347,'h8',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (348,'h8',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (349,'h8',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (350,'h8',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (351,'h9',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (352,'h9',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (346,'h8',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (353,'h9',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (528,'chun5',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (356,'h10',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (357,'h10',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (358,'h10',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (359,'h10',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (360,'h10',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (361,'h11',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (362,'h11',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (363,'h11',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (366,'h12',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (367,'h12',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (368,'h12',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (369,'h12',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (370,'h12',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (371,'h13',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (372,'h13',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (373,'h13',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (376,'h14',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (377,'h14',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (378,'h14',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (379,'h14',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (380,'h14',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (381,'h15',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (382,'h15',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (383,'h15',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (386,'h16',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (387,'h16',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (388,'h16',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (389,'h16',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (390,'h16',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (391,'h17',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (392,'h17',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (393,'h17',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (396,'h18',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (397,'h18',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (398,'h18',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (399,'h18',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (400,'h18',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (401,'h19',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (402,'h19',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (403,'h19',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (406,'h20',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (407,'h20',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (408,'h20',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (409,'h20',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (410,'h20',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (411,'h21',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (412,'h21',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (413,'h21',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (416,'h22',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (417,'h22',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (418,'h22',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (419,'h22',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (420,'h22',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (421,'h23',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (422,'h23',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (423,'h23',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (426,'h24',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (427,'h24',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (428,'h24',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (429,'h24',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (430,'h24',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (431,'h25',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (432,'h25',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (433,'h25',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (436,'h26',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (437,'h26',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (438,'h26',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (439,'h26',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (440,'h26',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (441,'h27',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (442,'h27',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (443,'h27',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (446,'h28',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (447,'h28',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (448,'h28',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (449,'h28',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (450,'h28',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (451,'h29',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (452,'h29',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (453,'h29',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (456,'h30',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (457,'h30',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (458,'h30',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (459,'h30',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (460,'h30',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (461,'h31',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (462,'h31',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (463,'h31',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (466,'h32',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (467,'h32',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (468,'h32',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (469,'h32',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (470,'h32',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (471,'h32',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (472,'h32',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (473,'h32',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (476,'h33',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (477,'h33',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (478,'h33',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (479,'h33',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (480,'h33',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (481,'h34',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (482,'h34',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (483,'h34',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (486,'h35',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (487,'h35',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (488,'h35',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (489,'h35',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (490,'h35',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (491,'h36',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (492,'h36',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (493,'h36',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (496,'h37',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (497,'h37',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (498,'h37',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (499,'h37',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (500,'h37',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (501,'h37',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (502,'h37',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (503,'h37',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (506,'h38',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (507,'h38',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (508,'h38',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (509,'h38',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (510,'h38',209);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (511,'h39',210);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (512,'h39',211);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (513,'h39',212);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (516,'h40',205);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (517,'h40',206);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (518,'h40',207);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (519,'h40',208);
Insert into PROJECT3.CART (CART_NUM,ID,BOOK_NUM) values (520,'h40',209);
