--------------------------------------------------------
--  ������ ������ - ������-3��-11-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table PCHECK
--------------------------------------------------------

  CREATE TABLE "PROJECT3"."PCHECK" 
   (	"ID" VARCHAR2(20 BYTE), 
	"POLL_NUM" NUMBER(20,0)
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into PROJECT3.PCHECK
SET DEFINE OFF;
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('manager',124);
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('manager',122);
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('v40',134);
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('manager',128);
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('h9',134);
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('manager',125);
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('chun4',134);
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('chun6',133);
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('manager',131);
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('manager',2);
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('manager',134);
Insert into PROJECT3.PCHECK (ID,POLL_NUM) values ('manager',130);
