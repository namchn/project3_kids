--------------------------------------------------------
--  ������ ������ - ������-3��-11-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table RENT
--------------------------------------------------------

  CREATE TABLE "PROJECT3"."RENT" 
   (	"RENT_NUM" NUMBER(30,0), 
	"BOOK_NUM" NUMBER(30,0), 
	"RENT_AMOUNT" NUMBER(10,0), 
	"ID" VARCHAR2(50 BYTE), 
	"S_DATE" DATE, 
	"E_DATE" DATE, 
	"R_DATE" DATE
   ) SEGMENT CREATION IMMEDIATE 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
REM INSERTING into PROJECT3.RENT
SET DEFINE OFF;
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (131,206,1,'h8',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),to_date('19/03/07','RR/MM/DD'));
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (132,207,2,'h8',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),to_date('19/03/07','RR/MM/DD'));
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (133,208,1,'h8',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),to_date('19/03/07','RR/MM/DD'));
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (134,209,2,'h8',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),to_date('19/03/07','RR/MM/DD'));
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (135,210,1,'h9',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),to_date('19/03/07','RR/MM/DD'));
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (136,211,2,'h9',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),to_date('19/03/07','RR/MM/DD'));
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (137,212,1,'h9',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (295,206,2,'manager',to_date('19/03/12','RR/MM/DD'),to_date('19/03/19','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (296,212,1,'chun4',to_date('19/03/05','RR/MM/DD'),to_date('19/03/12','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (140,205,2,'h10',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),to_date('19/03/04','RR/MM/DD'));
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (141,206,1,'h10',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (142,207,2,'h10',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (143,208,1,'h10',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (130,205,2,'h8',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (144,209,2,'h10',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (145,210,1,'h11',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (146,211,2,'h11',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (147,212,1,'h11',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (297,211,1,'chun5',to_date('19/03/05','RR/MM/DD'),to_date('19/03/12','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (298,211,1,'chun6',to_date('19/03/05','RR/MM/DD'),to_date('19/03/12','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (150,205,2,'h12',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (151,206,1,'h12',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (152,207,2,'h12',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (153,208,1,'h12',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (154,209,2,'h12',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (155,210,1,'h13',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (156,211,2,'h13',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (157,212,1,'h13',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (299,212,1,'manager',to_date('19/03/07','RR/MM/DD'),to_date('19/03/14','RR/MM/DD'),to_date('19/03/07','RR/MM/DD'));
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (300,212,1,'manager',to_date('19/03/07','RR/MM/DD'),to_date('19/03/14','RR/MM/DD'),to_date('19/03/07','RR/MM/DD'));
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (160,205,2,'h14',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (161,206,1,'h14',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (162,207,2,'h14',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (163,208,1,'h14',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (164,209,2,'h14',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (165,210,1,'h15',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (166,211,2,'h15',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (167,212,1,'h15',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (301,212,1,'manager',to_date('19/03/07','RR/MM/DD'),to_date('19/03/14','RR/MM/DD'),to_date('19/03/07','RR/MM/DD'));
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (302,212,1,'manager',to_date('19/03/07','RR/MM/DD'),to_date('19/03/14','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (170,205,2,'h16',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (171,206,1,'h16',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (172,207,2,'h16',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (173,208,1,'h16',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (174,209,2,'h16',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (175,210,1,'h17',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (176,211,2,'h17',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (177,212,1,'h17',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (303,212,1,'manager',to_date('19/03/07','RR/MM/DD'),to_date('19/03/14','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (304,212,1,'manager',to_date('19/03/07','RR/MM/DD'),to_date('19/03/14','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (180,205,2,'h18',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (181,206,1,'h18',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (182,207,2,'h18',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (183,208,1,'h18',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (184,209,2,'h18',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (185,210,1,'h19',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (186,211,2,'h19',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (187,212,1,'h19',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (190,205,2,'h20',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (191,206,1,'h20',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (192,207,2,'h20',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (193,208,1,'h20',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (194,209,2,'h20',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (195,210,1,'h21',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (196,211,2,'h21',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (197,212,1,'h21',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (200,205,2,'h22',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (201,206,1,'h22',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (202,207,2,'h22',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (203,208,1,'h22',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (204,209,2,'h22',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (205,210,1,'h23',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (206,211,2,'h23',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),to_date('19/03/04','RR/MM/DD'));
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (207,212,1,'h23',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (210,205,2,'h24',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (211,206,1,'h24',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (212,207,2,'h24',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (213,208,1,'h24',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (214,209,2,'h24',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (215,210,1,'h25',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (217,212,1,'h25',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (220,205,2,'h26',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (221,206,1,'h26',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (222,207,2,'h26',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (223,208,1,'h26',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (224,209,2,'h26',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (225,210,1,'h27',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (226,211,2,'h27',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (227,212,1,'h27',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (230,205,2,'h28',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (231,206,1,'h28',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (232,207,2,'h28',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (233,208,1,'h28',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (234,209,2,'h28',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (235,210,1,'h29',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (236,211,2,'h29',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (237,212,1,'h29',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (240,205,2,'h30',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (241,206,1,'h30',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (242,207,2,'h30',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (243,208,1,'h30',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (244,209,2,'h30',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (245,210,1,'h31',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (246,211,2,'h31',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (247,212,1,'h31',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (250,205,2,'h32',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (251,206,1,'h32',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (252,207,2,'h32',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (253,208,1,'h32',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (254,209,2,'h32',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (255,210,1,'h33',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (256,211,2,'h33',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (257,212,1,'h33',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (260,205,2,'h34',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (261,206,1,'h34',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (262,207,2,'h34',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (263,208,1,'h34',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (264,209,2,'h34',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (265,210,1,'h35',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (266,211,2,'h35',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (267,212,1,'h35',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (270,205,2,'h36',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (271,206,1,'h36',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (272,207,2,'h36',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (273,208,1,'h36',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (274,209,2,'h36',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (275,210,1,'h37',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (276,211,2,'h37',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (277,212,1,'h37',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (280,205,2,'h38',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (281,206,1,'h38',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (282,207,2,'h38',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (283,208,1,'h38',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (284,209,2,'h38',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (285,210,1,'h39',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (286,211,2,'h39',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (287,212,1,'h39',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (290,210,1,'h40',to_date('19/02/26','RR/MM/DD'),to_date('19/03/05','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (291,211,2,'h40',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
Insert into PROJECT3.RENT (RENT_NUM,BOOK_NUM,RENT_AMOUNT,ID,S_DATE,E_DATE,R_DATE) values (292,212,1,'h40',to_date('19/02/27','RR/MM/DD'),to_date('19/03/06','RR/MM/DD'),null);
